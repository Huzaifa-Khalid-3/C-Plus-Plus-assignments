#ifndef NORMALTEST_H
#define NORMALTEST_H

#include "Test.h"
#include <random>

class NormalTest: public Test<int>{
public:
	NormalTest(int sc) {
		generateNumbers(sc);
	}

	void generateNumbers(int sc) override {
		std::random_device rd;
		std::mt19937 gen(rd());
		std::normal_distribution<> dist(0, 100);

		numbers.clear();
		for (int i = 0; i < sc; ++i) {
			numbers.push_back(static_cast<int>(dist(gen)));
		}

	}
	int getMax() const override {
		return *std::max_element(numbers.begin(), numbers.end());
	}
	int getMin() const override {
		return *std::min_element(numbers.begin(), numbers.end());
	}
	int getMedian() const override {
		std::vector<int> sortNum = numbers;
		std::sort(sortNum.begin(), sortNum.end());
		return sortNum[sortNum.size() / 2];
	}
	int getNumberRange() const override {
		return getMax() - getMin();
	}
	std::map<int, int> getHistogram() const override {
		std::map<int, int> histogram;
		int min = getMin();
		int max = getMax();
		int range = max - min;
		

		int size = (range + 19) / 20;

		// initlaize histogram
		for (int j = 0; j < 20; ++j) {
			histogram[min + j * size] = 0;
		}

		for (int k = 0; k < numbers.size(); k++) {
			int index = (numbers[k] - min) / size;
			index = std::min(index, 19);
			int start = min + index * size;
			histogram[start]++;
		}
		return histogram;
	}
};
#endif