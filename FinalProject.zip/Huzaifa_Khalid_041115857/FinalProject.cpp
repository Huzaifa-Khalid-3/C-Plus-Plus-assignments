#include <iostream>
#include "FinalProject.h"
#include "UniformTest.h"
#include "NormalTest.h"
#include "Test.h"
using namespace std;
template <typename T>
void runTests(Test<T>* pTest) {
	cout << "Min: " << pTest->getMin() << endl;
	cout << "Max: " << pTest->getMax() << endl;
	cout << "Median: " << pTest->getMedian() << endl;
	cout << "Range: " << pTest->getNumberRange() << endl;

	cout << "Histogram: " << endl;
	auto histogram = pTest->getHistogram();
	for (const auto& set : histogram) {
		const auto& b = set.first;
		const auto& c = set.second;
		cout << b << " - " << (b + 5) << ": " << c << endl;
	}
}

JNIEXPORT void JNICALL Java_FinalProject_RunUniform(JNIEnv* env, jobject obj, jint sc) {
	if (sc <= 1)
		return;
	UniformTest test(sc);
	std::cout << "Uniform distribution test" << std::endl;
	runTests(&test);
}
JNIEXPORT void JNICALL Java_FinalProject_RunNormal(JNIEnv* env, jobject obj, jint sc) {
	if (sc <= 1)
		return;
	NormalTest test(sc);
	std::cout << "Normal distribution test" << std::endl;
	runTests(&test);
}

