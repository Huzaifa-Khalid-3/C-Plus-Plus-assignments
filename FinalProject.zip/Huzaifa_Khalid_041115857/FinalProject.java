import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class FinalProject {

	public native void RunUniform(int sc);
	public native void RunNormal(int sc);
	
	static {
		System.loadLibrary("MyCppLibrary");
}
	
	public static void main(String[] args) {
		JFrame frame = new JFrame("Distribution test");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(300,200);
		
		JPanel p = new JPanel();
		frame.add(p);
		
		JLabel l = new JLabel("Enter sample count:");
		JTextField sf = new JTextField(10);
		
		JButton ub = new JButton("Run uniform");
		JButton nb = new JButton("Run normal");
		
		p.add(l);
		p.add(sf);
		p.add(ub);
		p.add(nb);
		
		FinalProject fp = new FinalProject();
		
		ub.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					int sc = Integer.parseInt(sf.getText());
					if (sc <= 1)
						JOptionPane.showMessageDialog(frame, "Error, Count must be greater than 1 ");
					fp.RunUniform(sc);
			} catch(NumberFormatException e1) {
				JOptionPane.showMessageDialog(frame, "Error, Enter valid number");
				}
			}
		});
		nb.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					int sc = Integer.parseInt(sf.getText());
					if (sc <= 1)
						JOptionPane.showMessageDialog(frame, "Error, Count must be greater than 1 ");
					fp.RunNormal(sc);	
				} catch(NumberFormatException e1) {
					JOptionPane.showMessageDialog(frame, "Error, Enter valid number");
					}
			}
		});
		frame.setVisible(true);
	}
}