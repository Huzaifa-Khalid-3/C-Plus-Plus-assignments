#ifndef TEST_H
#define TEST_H

#include <vector>
#include <map>
#include<algorithm>

template<typename T>
class Test
{
protected:
	std::vector<T> numbers;
public:
	virtual ~Test() = default;
	virtual void generateNumbers(int sc) = 0;
	virtual T getMin() const = 0;
	virtual T getMax() const = 0;
	virtual T getMedian() const = 0;
	virtual T getNumberRange() const = 0;
	virtual std::map<int, int> getHistogram() const = 0;
};

#endif


